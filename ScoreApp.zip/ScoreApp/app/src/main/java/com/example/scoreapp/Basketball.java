package com.example.scoreapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Basketball extends AppCompatActivity {

    TextView Next,Visi;
    EditText TEAM1,TEAM2;
    Spinner spinner;

    public static String value1,value2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basketball);

        Next = findViewById(R.id.next);
        TEAM1 = findViewById(R.id.team1);
        TEAM2 = findViewById(R.id.team2);
        Spinner spinner = findViewById(R.id.Spinner);
        Visi = findViewById(R.id.visitxt);

        value1 = TEAM1.getText().toString();
        value2 = TEAM2.getText().toString();





        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Team1 = TEAM1.getText().toString().trim();
                String Team2 = TEAM2.getText().toString().trim();

                if (Team1.isEmpty() && Team2.isEmpty()){

                    TEAM1.setError("Enter The TEAM NAME");
                    TEAM2.setError("Enter The TEAM NAME");

                    return;

                }else {

                    Intent intent = new Intent(Basketball.this, Basket_ball2.class);
                    intent.putExtra("TEAM1",Team1);
                    intent.putExtra("TEAM2",Team2);
                    startActivity(intent);
                    finish();
                }


            }


        });


    }

    public static String getvalue(){
        return value1;

    }
    public static String getValue1(){
        return value2;
    }



}