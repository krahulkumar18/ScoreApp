package com.example.scoreapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Scorecard extends AppCompatActivity {

    Button BASKETBALL,BADMINTON,HOCKEY,Football,Cricket,QUIT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scorecard);

        BASKETBALL = findViewById(R.id.basketball);
        BADMINTON = findViewById(R.id.badminton);
        HOCKEY = findViewById(R.id.Hockey);
        Football = findViewById(R.id.Football);
        Cricket = findViewById(R.id.cricket);
        QUIT = findViewById(R.id.quit);


        BASKETBALL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Scorecard.this, Basketball.class);
                startActivity(intent);



            }
        });

        BADMINTON.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Scorecard.this, Badminton.class);
                startActivity(intent);
            }
        });




        HOCKEY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Scorecard.this, Hockey.class);
                startActivity(intent);
            }
        });

        Football.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Scorecard.this, Football.class);
                startActivity(intent);
            }
        });

        Cricket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Scorecard.this, Cricket.class);
                startActivity(intent);
            }
        });

        QUIT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Scorecard.this.finish();

            }
        });



    }
}