package com.example.scoreapp;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.scoreapp.R;

public class Basket_ball2 extends AppCompatActivity {

    TextView Next,Teamname1,Teamname2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basket_ball2);

        Next = findViewById(R.id.next);
        Teamname1 = findViewById(R.id.teamname1);
        Teamname2 = findViewById(R.id.teamname2);



        Bundle bundle = getIntent().getExtras();
        assert bundle != null;

        String team1 = bundle.getString("TEAM1");
        String team2 = bundle.getString("TEAM2");


        Teamname1.setText(" " + team1);
        Teamname2.setText("" + team2);


        



        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Basket_ball2.this, B_Ball3.class);
                intent.putExtra("TEAM1",team1);
                intent.putExtra("TEAM2",team2);
                startActivity(intent);
                finish();
                }

        });


    }
}