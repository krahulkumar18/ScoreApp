package com.example.scoreapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Cricket extends AppCompatActivity {

    Button ONE,TWO,THREE,FOUR,SIX,WIDE,NOBALL,OUT,CONVERT,EXTRAS,CLR,RUNOUT;
    EditText EDRUNS,EDWICKETS,CIVED,BALLSED,EXTCOUNT;
    TextView TTRUNS,TTWICKETS,TTBALLS;
    int runs = 0 , wickets = 0, balls = 0;
    double overs=0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cricket);

        ONE = findViewById(R.id.one);
        TWO = findViewById(R.id.two);
        THREE = findViewById(R.id.three);
        FOUR = findViewById(R.id.four);
        SIX = findViewById(R.id.six);
        WIDE = findViewById(R.id.wideball);
        NOBALL = findViewById(R.id.noball);
        OUT = findViewById(R.id.out);
        CONVERT = findViewById(R.id.civ);
        EXTRAS = findViewById(R.id.extras);
        EDRUNS = findViewById(R.id.ed1runs);
        EDWICKETS = findViewById(R.id.ed2wickets);
        CIVED = findViewById(R.id.CIVED);
        BALLSED = findViewById(R.id.ballsed);
        TTRUNS = findViewById(R.id.ttruns);
        TTBALLS = findViewById(R.id.ttballs);
        TTWICKETS = findViewById(R.id.ttwickets);
        EXTCOUNT = findViewById(R.id.ext1);
        CLR = findViewById(R.id.clr);
        RUNOUT = findViewById(R.id.runout);



        ONE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                runs = runs+1;
                EDRUNS.setText(Integer.toString(runs));
                balls=balls+1;
                CIVED.setText(Integer.toString(balls));
            }
        });

        TWO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                runs = runs+2;
                EDRUNS.setText(Integer.toString(runs));
                balls=balls+1;
                CIVED.setText(Integer.toString(balls));

            }
        });

        THREE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                runs = runs+3;
                EDRUNS.setText(Integer.toString(runs));
                balls=balls+1;
                CIVED.setText(Integer.toString(balls));
            }
        });

        FOUR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runs = runs+4;
                EDRUNS.setText(Integer.toString(runs));
                balls=balls+1;
                CIVED.setText(Integer.toString(balls));
            }
        });

        SIX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runs = runs+6;
                EDRUNS.setText(Integer.toString(runs));
                balls=balls+1;
                CIVED.setText(Integer.toString(balls));
            }
        });

        WIDE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                runs = runs+1;
                EDRUNS.setText(Integer.toString(runs));

            }
        });

        NOBALL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                runs = runs+1;
                EDRUNS.setText(Integer.toString(runs));


            }
        });

        OUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                wickets = wickets+1;
                EDWICKETS.setText(Integer.toString(wickets));
                balls = balls+1;
                CIVED.setText(Integer.toString(balls));

            }
        });

        CONVERT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String no=CIVED.getText().toString();
                int a = Integer.parseInt(no);
                int rem = a%6;
                int quotient = a/6;
                BALLSED.setText(quotient+"."+rem);

            }
        });

        EXTRAS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String no= EXTCOUNT.getText().toString();
                int zero = 0;
                int a = Integer.parseInt(no);
                runs = runs+a;
                EDRUNS.setText(Integer.toString(runs));
                EXTCOUNT.setText(Integer.toString(zero));



            }
        });

        CLR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EDRUNS.setText("");
                EDWICKETS.setText("");
                CIVED.setText("");
                BALLSED.setText("");

            }
        });

        RUNOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                wickets = wickets+1;
                EDWICKETS.setText(Integer.toString(wickets));
                balls = balls+1;
                CIVED.setText(Integer.toString(balls));




            }
        });




    }

    }
